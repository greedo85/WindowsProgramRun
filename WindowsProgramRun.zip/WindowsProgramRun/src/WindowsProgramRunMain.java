import methods.FieldClass;

import javax.swing.*;

public class WindowsProgramRunMain extends FieldClass
{
	public static void main ( String[]args)
	{
		
		src.methods.WindowsProgramRun.WindowsProgramRun wpr1=new src.methods.WindowsProgramRun.WindowsProgramRun();
		wpr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		wpr1.setSize(500,200);
		/* wpr.pack(); */
		wpr1.setVisible(true);
		wpr1.setTitle("Uruchamiacz program�w");
	}
}
	