package methods;

import javax.swing.*;


public class FieldClass extends JFrame
{
    public JButton button1,button2,button3,button4,button5,button6,button7,button8;
    public JLabel label1,label2;
    public JTextField field1, field2, field3,field4;
    public JTextArea infoField;
    public String pathToBrowser,pathToMail,pathToUser1,pathToUser2,buttonNameUser1,buttonNameUser2;
    public JMenuBar menuBar=new JMenuBar();
    public JMenu file;
    public JMenuItem close;
    public JMenuItem about;
    public String info=" Ustaw przyciski w pliku config.txt. Ostatnie dwa ustawiane s� od linii 3" +
            "do 6.\n Wpisz najpierw nazw� procesu a potem �cie�k� do niego";

}
