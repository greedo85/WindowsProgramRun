/* package WindowsProgramRun; */
package src.methods.WindowsProgramRun;
import methods.FieldClass;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;import javax.swing.*;
import java.awt.event.ActionEvent;


public class WindowsProgramRun extends JFrame
{
	public static final String KILL="taskkill /F /IM ";
	Event1 ev1=new Event1();
	Event2 ev2=new Event2();
	Event3 ev3=new Event3();
	Event4 ev4=new Event4();
	Event5 ev5=new Event5();
	Event6 ev6=new Event6();
	Event7 ev7=new Event7();
	Event8 ev8=new Event8();
	FieldClass fc = new FieldClass();
	MenuEvent1 mev1=new MenuEvent1();
	MenuEvent2 mev2=new MenuEvent2();
	Runtime run;

	public WindowsProgramRun()
	{
		setLayout(new FlowLayout());

		setJMenuBar(fc.menuBar);
		fc.file=new JMenu("Plik");
		fc.menuBar.add(fc.file);

		fc.about=new JMenuItem("Instrukcja");
		fc.close=new JMenuItem("Zamknij");
		fc.file.add(fc.about);
		fc.file.add(fc.close);


		fc.about.addActionListener(mev1);
		fc.close.addActionListener(mev2);
		run=Runtime.getRuntime();
		try
		{
			File file=new File("C:\\Programy Java\\WindowsProgramRun\\src\\config.txt");
			Scanner key=new Scanner(file);
			fc.pathToBrowser=key.nextLine();
			fc.pathToMail=key.nextLine();
			fc.buttonNameUser1=key.nextLine();
			fc.pathToUser1=key.nextLine();
			fc.buttonNameUser2=key.nextLine();
			fc.pathToUser2=key.nextLine();
		}
		catch (FileNotFoundException e)
		{
			fc.label2.setText("plik nie istnieje");//to trzeba jeszcze sprawdzi�
		}
		
		setLayout(new GridBagLayout());
		GridBagConstraints gbc=new GridBagConstraints();
		fc.label1=new JLabel("Uruchamiacz program�w");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=0;
		add(fc.label1,gbc);

		fc.label2=new JLabel("");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=0;
		add(fc.label2,gbc);

		fc.button1=new JButton("Przegl�darka");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=1;
		add(fc.button1,gbc);
		fc.button1.addActionListener(ev1);

		fc.field1=new JTextField(20);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=1;
		add(fc.field1,gbc);

		fc.button2=new JButton("X");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=4;
		gbc.gridy=1;
		add(fc.button2,gbc);
		fc.button2.addActionListener(ev2);
	/* --------------------------------------------------- */
		fc.button3=new JButton("Poczta");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=2;
		add(fc.button3,gbc);
		fc.button3.addActionListener(ev3);

		fc.field2=new JTextField(20);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=2;
		add(fc.field2,gbc);

		fc.button4=new JButton("X");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=4;
		gbc.gridy=2;
		add(fc.button4,gbc);
		fc.button4.addActionListener(ev4);
	/* -------------------------------------------------- */
		fc.button5=new JButton(fc.buttonNameUser1);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=3;
		add(fc.button5,gbc);
		fc.button5.addActionListener(ev5);

		fc.field3=new JTextField(20);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=3;
		add(fc.field3,gbc);

		fc.button6=new JButton("X");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=4;
		gbc.gridy=3;
		add(fc.button6,gbc);
		fc.button6.addActionListener(ev6);
		/*------------------------------*/
		fc.button7=new JButton(fc.buttonNameUser2);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=0;
		gbc.gridy=4;
		add(fc.button7,gbc);
		fc.button7.addActionListener(ev7);

		fc.field4=new JTextField(20);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=1;
		gbc.gridy=4;
		add(fc.field4,gbc);

		fc.button8=new JButton("X");
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridx=4;
		gbc.gridy=4;
		add(fc.button8,gbc);
		fc.button8.addActionListener(ev8);
		fc.infoField=new JTextArea(fc.info);
		fc.infoField.setText(fc.info);
		fc.infoField.setPreferredSize(new Dimension(100,100));

	}
	public int runProcess(int choice1)
	{
		try
		{
			switch(choice1)
			{
				case 1:
					run.exec(fc.pathToBrowser+" -ProfileManager");
					break;
				case 2:
					run.exec(fc.pathToMail);
					break;
				case 3:
					run.exec(fc.pathToUser1);
					break;
				case 4:
					run.exec(fc.pathToUser2);
					break;
			}
		}
		catch (Exception Ex)
        {
		  System.out.println("B��d " + Ex.toString());
	    }
		return choice1;
	}
	public int closeProcess(int choice2)
	{
		run=Runtime.getRuntime();
		try
		{
			switch (choice2)
			{
				case 1:
					run.exec(KILL+"firefox.exe");
					break;
				case 2:
					run.exec(KILL+"thunderbird.exe");
					break;
				case 3:
					run.exec(KILL+fc.buttonNameUser1+".exe");
					break;
				case 4:
					run.exec(KILL+fc.buttonNameUser2+".exe");
					break;
			}
		}
		catch (Exception Ex)
        {
		  System.out.println("B��d " + Ex.toString());
	    }
		return choice2;
	}
	public void information()
	{
		JFrame frame = new JFrame("Instrukcja");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//zamyka tylko jedneo okno
		frame.getContentPane().add(fc.infoField, BorderLayout.NORTH);
		frame.setSize(600,300);
		frame.setVisible(true);
	}
	public class MenuEvent1 implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent mev)
		{
			information();
		}
	}
	public class MenuEvent2 implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent mev)
		{
			System.exit(1);
		}
	}

	public class Event1 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev1)
		{
			runProcess(1);
			fc.field1.setText(fc.pathToBrowser);
			revalidate();
		}
	}
	public class Event2 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev2)
		{
			closeProcess(1);
			fc.field1.setText("");
			revalidate();
		}
	}
	public class Event3 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev3)
		{
			runProcess(2);
			fc.field2.setText(fc.pathToMail);
			revalidate();
		}
	}
	public class Event4 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev4)
		{
			closeProcess(2);
			fc.field2.setText("");
			revalidate();
		}
	}
	public class Event5 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev5)
		{
			runProcess(3);
			fc.field3.setText(fc.pathToUser1);
			revalidate();
		}
	}
	public class Event6 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev6)
		{
			closeProcess(3);
			fc.field3.setText("");
			revalidate();
		}
	}
	public class Event7 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev7)
		{
            runProcess(4);
			fc.field4.setText(fc.pathToUser2);
			revalidate();
		}
	}
	public class Event8 implements ActionListener
	{
		public void actionPerformed(ActionEvent ev8)
		{
			closeProcess(4);
			fc.field4.setText("");
			revalidate();
		}
	}
	
}